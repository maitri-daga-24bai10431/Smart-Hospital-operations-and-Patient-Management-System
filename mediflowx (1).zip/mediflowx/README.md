# MediFlowX – Smart Hospital Operations and Patient Management System

A Spring Boot 3.x + MongoDB backend for hospital operations management.

## Tech Stack
- Java 21
- Spring Boot 3.3.4
- MongoDB (Spring Data MongoDB)
- Maven
- Lombok
- springdoc-openapi (Swagger UI)

## Modules
- Patients
- Doctors
- Departments
- Appointments
- Medicines

## Relationships
- **Department → Doctors**: One-to-Many (`Department.doctorIds`, `Doctor.departmentId`)
- **Doctor → Appointments**: One-to-Many (`Doctor.appointmentIds`)
- **Doctor → Department**: Many-to-One (`Doctor.departmentId`)
- **Patients ↔ Doctors**: Many-to-Many (`Patient.doctorIds`, `Doctor.patientIds`)
- **Patient → Appointments / Doctor → Appointments**: Appointment references both `doctorId` and `patientId`

Relationships are maintained at the service layer via document reference IDs (standard MongoDB pattern), keeping both sides of each relation in sync on create/update/delete.

## Project Structure
```
src/main/java/com/mediflowx
├── MediFlowXApplication.java
├── config/OpenApiConfig.java
├── controller/
│   ├── DepartmentController.java
│   ├── DoctorController.java
│   ├── PatientController.java
│   ├── AppointmentController.java
│   └── MedicineController.java
├── service/
│   ├── DepartmentService.java
│   ├── DoctorService.java
│   ├── PatientService.java
│   ├── AppointmentService.java
│   └── MedicineService.java
├── repository/
│   ├── DepartmentRepository.java
│   ├── DoctorRepository.java
│   ├── PatientRepository.java
│   ├── AppointmentRepository.java
│   └── MedicineRepository.java
├── model/
│   ├── Department.java
│   ├── Doctor.java
│   ├── Patient.java
│   ├── Appointment.java
│   └── Medicine.java
├── dto/
│   ├── DepartmentDTO.java
│   ├── DoctorDTO.java
│   ├── PatientDTO.java
│   ├── AppointmentDTO.java
│   └── MedicineDTO.java
└── exception/
    ├── GlobalExceptionHandler.java
    ├── ResourceNotFoundException.java
    └── ErrorResponse.java
```

## MongoDB Configuration
Edit `src/main/resources/application.properties`:
```properties
spring.data.mongodb.uri=mongodb://localhost:27017/mediflowx
spring.data.mongodb.database=mediflowx
server.port=8080
```

For MongoDB Atlas:
```properties
spring.data.mongodb.uri=mongodb+srv://<username>:<password>@<cluster-url>/mediflowx?retryWrites=true&w=majority
```

## Build & Run
```bash
mvn clean install
mvn spring-boot:run
```

## Swagger UI
After starting the app:
- Swagger UI: http://localhost:8080/swagger-ui.html
- OpenAPI docs: http://localhost:8080/api-docs

## Base API Endpoints

| Module       | Base Path              |
|---------------|------------------------|
| Departments  | `/api/departments`     |
| Doctors      | `/api/doctors`         |
| Patients     | `/api/patients`        |
| Appointments | `/api/appointments`    |
| Medicines    | `/api/medicines`       |

All modules support: `POST`, `GET` (all + by id), `PUT /{id}`, `DELETE /{id}`.

Extra endpoints:
- `GET /api/doctors/department/{departmentId}` – doctors in a department
- `POST /api/doctors/{doctorId}/patients/{patientId}` – link doctor↔patient
- `DELETE /api/doctors/{doctorId}/patients/{patientId}` – unlink doctor↔patient
- `GET /api/appointments/doctor/{doctorId}` – appointments by doctor
- `GET /api/appointments/patient/{patientId}` – appointments by patient

See `sample-requests.md` for sample JSON payloads.
