# Sample JSON Requests & Responses

## 1. Department

### POST /api/departments
Request:
```json
{
  "name": "Cardiology",
  "description": "Heart and cardiovascular care",
  "location": "Block A, Floor 2"
}
```
Response (201):
```json
{
  "id": "665f1a2b3c4d5e6f7a8b9c01",
  "name": "Cardiology",
  "description": "Heart and cardiovascular care",
  "location": "Block A, Floor 2",
  "doctorIds": []
}
```

## 2. Doctor

### POST /api/doctors
Request:
```json
{
  "name": "Dr. Sarah Johnson",
  "specialization": "Cardiologist",
  "email": "sarah.johnson@mediflowx.com",
  "phone": "+91-9876543210",
  "departmentId": "665f1a2b3c4d5e6f7a8b9c01"
}
```
Response (201):
```json
{
  "id": "665f1a2b3c4d5e6f7a8b9c02",
  "name": "Dr. Sarah Johnson",
  "specialization": "Cardiologist",
  "email": "sarah.johnson@mediflowx.com",
  "phone": "+91-9876543210",
  "departmentId": "665f1a2b3c4d5e6f7a8b9c01",
  "appointmentIds": [],
  "patientIds": []
}
```

## 3. Patient

### POST /api/patients
Request:
```json
{
  "name": "John Doe",
  "age": 45,
  "gender": "Male",
  "email": "john.doe@example.com",
  "phone": "+91-9123456780",
  "address": "123 MG Road, Mumbai"
}
```
Response (201):
```json
{
  "id": "665f1a2b3c4d5e6f7a8b9c03",
  "name": "John Doe",
  "age": 45,
  "gender": "Male",
  "email": "john.doe@example.com",
  "phone": "+91-9123456780",
  "address": "123 MG Road, Mumbai",
  "doctorIds": [],
  "appointmentIds": []
}
```

## 4. Link Doctor ↔ Patient (Many-to-Many)

### POST /api/doctors/665f1a2b3c4d5e6f7a8b9c02/patients/665f1a2b3c4d5e6f7a8b9c03
Response: `200 OK`

## 5. Appointment

### POST /api/appointments
Request:
```json
{
  "doctorId": "665f1a2b3c4d5e6f7a8b9c02",
  "patientId": "665f1a2b3c4d5e6f7a8b9c03",
  "appointmentDateTime": "2026-06-20T10:30:00",
  "reason": "Routine heart checkup",
  "notes": "Patient reports occasional chest discomfort"
}
```
Response (201):
```json
{
  "id": "665f1a2b3c4d5e6f7a8b9c04",
  "doctorId": "665f1a2b3c4d5e6f7a8b9c02",
  "patientId": "665f1a2b3c4d5e6f7a8b9c03",
  "appointmentDateTime": "2026-06-20T10:30:00",
  "reason": "Routine heart checkup",
  "status": "SCHEDULED",
  "notes": "Patient reports occasional chest discomfort"
}
```

## 6. Medicine

### POST /api/medicines
Request:
```json
{
  "name": "Atorvastatin",
  "manufacturer": "Pfizer",
  "description": "Cholesterol-lowering medication",
  "price": 12.50,
  "stockQuantity": 500,
  "dosageForm": "Tablet",
  "expiryDate": "2027-12-31"
}
```
Response (201):
```json
{
  "id": "665f1a2b3c4d5e6f7a8b9c05",
  "name": "Atorvastatin",
  "manufacturer": "Pfizer",
  "description": "Cholesterol-lowering medication",
  "price": 12.50,
  "stockQuantity": 500,
  "dosageForm": "Tablet",
  "expiryDate": "2027-12-31"
}
```

## 7. Error Response Example (Validation)

### POST /api/patients (missing required fields)
Response (400):
```json
{
  "timestamp": "2026-06-13T10:00:00",
  "status": 400,
  "error": "Bad Request",
  "message": "Validation failed",
  "path": "/api/patients",
  "validationErrors": {
    "name": "Patient name is required",
    "age": "Age is required",
    "email": "Email is required"
  }
}
```

## 8. Error Response Example (Not Found)

### GET /api/patients/000000000000000000000000
Response (404):
```json
{
  "timestamp": "2026-06-13T10:05:00",
  "status": 404,
  "error": "Not Found",
  "message": "Patient not found with id: 000000000000000000000000",
  "path": "/api/patients/000000000000000000000000"
}
```
