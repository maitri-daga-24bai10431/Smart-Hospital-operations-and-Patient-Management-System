package com.mediflowx.controller;

import com.mediflowx.dto.DoctorDTO;
import com.mediflowx.service.DoctorService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/doctors")
@RequiredArgsConstructor
@Tag(name = "Doctors", description = "Manage doctors")
public class DoctorController {

    private final DoctorService doctorService;

    @PostMapping
    @Operation(summary = "Create a new doctor")
    public ResponseEntity<DoctorDTO> createDoctor(@Valid @RequestBody DoctorDTO dto) {
        return new ResponseEntity<>(doctorService.createDoctor(dto), HttpStatus.CREATED);
    }

    @GetMapping
    @Operation(summary = "Get all doctors")
    public ResponseEntity<List<DoctorDTO>> getAllDoctors() {
        return ResponseEntity.ok(doctorService.getAllDoctors());
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get doctor by id")
    public ResponseEntity<DoctorDTO> getDoctorById(@PathVariable String id) {
        return ResponseEntity.ok(doctorService.getDoctorById(id));
    }

    @GetMapping("/department/{departmentId}")
    @Operation(summary = "Get doctors by department id")
    public ResponseEntity<List<DoctorDTO>> getDoctorsByDepartment(@PathVariable String departmentId) {
        return ResponseEntity.ok(doctorService.getDoctorsByDepartment(departmentId));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update doctor")
    public ResponseEntity<DoctorDTO> updateDoctor(@PathVariable String id,
                                                    @Valid @RequestBody DoctorDTO dto) {
        return ResponseEntity.ok(doctorService.updateDoctor(id, dto));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete doctor")
    public ResponseEntity<Void> deleteDoctor(@PathVariable String id) {
        doctorService.deleteDoctor(id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/{doctorId}/patients/{patientId}")
    @Operation(summary = "Link a patient to a doctor (many-to-many)")
    public ResponseEntity<Void> linkPatient(@PathVariable String doctorId, @PathVariable String patientId) {
        doctorService.linkPatient(doctorId, patientId);
        return ResponseEntity.ok().build();
    }

    @DeleteMapping("/{doctorId}/patients/{patientId}")
    @Operation(summary = "Unlink a patient from a doctor (many-to-many)")
    public ResponseEntity<Void> unlinkPatient(@PathVariable String doctorId, @PathVariable String patientId) {
        doctorService.unlinkPatient(doctorId, patientId);
        return ResponseEntity.noContent().build();
    }
}
