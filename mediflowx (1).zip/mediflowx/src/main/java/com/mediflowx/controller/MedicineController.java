package com.mediflowx.controller;

import com.mediflowx.dto.MedicineDTO;
import com.mediflowx.service.MedicineService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/medicines")
@RequiredArgsConstructor
@Tag(name = "Medicines", description = "Manage hospital medicine inventory")
public class MedicineController {

    private final MedicineService medicineService;

    @PostMapping
    @Operation(summary = "Create a new medicine")
    public ResponseEntity<MedicineDTO> createMedicine(@Valid @RequestBody MedicineDTO dto) {
        return new ResponseEntity<>(medicineService.createMedicine(dto), HttpStatus.CREATED);
    }

    @GetMapping
    @Operation(summary = "Get all medicines")
    public ResponseEntity<List<MedicineDTO>> getAllMedicines() {
        return ResponseEntity.ok(medicineService.getAllMedicines());
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get medicine by id")
    public ResponseEntity<MedicineDTO> getMedicineById(@PathVariable String id) {
        return ResponseEntity.ok(medicineService.getMedicineById(id));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update medicine")
    public ResponseEntity<MedicineDTO> updateMedicine(@PathVariable String id,
                                                        @Valid @RequestBody MedicineDTO dto) {
        return ResponseEntity.ok(medicineService.updateMedicine(id, dto));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete medicine")
    public ResponseEntity<Void> deleteMedicine(@PathVariable String id) {
        medicineService.deleteMedicine(id);
        return ResponseEntity.noContent().build();
    }
}
