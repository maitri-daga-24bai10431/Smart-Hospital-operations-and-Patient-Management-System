package com.mediflowx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MediFlowXApplication {
    public static void main(String[] args) {
        SpringApplication.run(MediFlowXApplication.class, args);
    }
}
