package com.mediflowx.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AppointmentDTO {

    private String id;

    @NotBlank(message = "Doctor id is required")
    private String doctorId;

    @NotBlank(message = "Patient id is required")
    private String patientId;

    @NotNull(message = "Appointment date and time is required")
    private LocalDateTime appointmentDateTime;

    @NotBlank(message = "Reason is required")
    private String reason;

    private String status;

    private String notes;
}
