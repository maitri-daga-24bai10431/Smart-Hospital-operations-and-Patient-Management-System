package com.mediflowx.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "medicines")
public class Medicine {

    @Id
    private String id;

    private String name;

    private String manufacturer;

    private String description;

    private Double price;

    private Integer stockQuantity;

    private String dosageForm; // Tablet, Syrup, Injection etc.

    private String expiryDate;
}
