package com.mediflowx.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "appointments")
public class Appointment {

    @Id
    private String id;

    // Many-to-One: Appointment -> Doctor
    private String doctorId;

    // Many-to-One: Appointment -> Patient
    private String patientId;

    private LocalDateTime appointmentDateTime;

    private String reason;

    private String status; // SCHEDULED, COMPLETED, CANCELLED

    private String notes;
}
