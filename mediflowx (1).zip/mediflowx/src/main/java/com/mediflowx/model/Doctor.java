package com.mediflowx.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.ArrayList;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "doctors")
public class Doctor {

    @Id
    private String id;

    private String name;

    private String specialization;

    private String email;

    private String phone;

    // Many-to-One: Doctor -> Department
    private String departmentId;

    // One-to-Many: Doctor -> Appointments
    @Builder.Default
    private List<String> appointmentIds = new ArrayList<>();

    // Many-to-Many: Doctors <-> Patients
    @Builder.Default
    private List<String> patientIds = new ArrayList<>();
}
