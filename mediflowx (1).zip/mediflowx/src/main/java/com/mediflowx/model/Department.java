package com.mediflowx.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.ArrayList;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "departments")
public class Department {

    @Id
    private String id;

    private String name;

    private String description;

    private String location;

    // One-to-Many: Department -> Doctors (stores doctor ids)
    @Builder.Default
    private List<String> doctorIds = new ArrayList<>();
}
