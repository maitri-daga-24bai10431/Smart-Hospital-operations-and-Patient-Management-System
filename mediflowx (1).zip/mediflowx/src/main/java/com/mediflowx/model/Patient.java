package com.mediflowx.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.ArrayList;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "patients")
public class Patient {

    @Id
    private String id;

    private String name;

    private Integer age;

    private String gender;

    private String email;

    private String phone;

    private String address;

    // Many-to-Many: Patients <-> Doctors
    @Builder.Default
    private List<String> doctorIds = new ArrayList<>();

    // One-to-Many (Patient -> Appointments)
    @Builder.Default
    private List<String> appointmentIds = new ArrayList<>();
}
