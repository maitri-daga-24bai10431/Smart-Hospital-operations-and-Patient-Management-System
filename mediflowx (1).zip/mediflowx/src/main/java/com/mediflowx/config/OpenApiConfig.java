package com.mediflowx.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI mediFlowXOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("MediFlowX API")
                        .description("Smart Hospital Operations and Patient Management System")
                        .version("v1.0.0"));
    }
}
