package com.mediflowx.service;

import com.mediflowx.dto.AppointmentDTO;
import com.mediflowx.exception.ResourceNotFoundException;
import com.mediflowx.model.Appointment;
import com.mediflowx.model.Doctor;
import com.mediflowx.model.Patient;
import com.mediflowx.repository.AppointmentRepository;
import com.mediflowx.repository.DoctorRepository;
import com.mediflowx.repository.PatientRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AppointmentService {

    private final AppointmentRepository appointmentRepository;
    private final DoctorRepository doctorRepository;
    private final PatientRepository patientRepository;

    public AppointmentDTO createAppointment(AppointmentDTO dto) {
        Doctor doctor = doctorRepository.findById(dto.getDoctorId())
                .orElseThrow(() -> new ResourceNotFoundException("Doctor not found with id: " + dto.getDoctorId()));
        Patient patient = patientRepository.findById(dto.getPatientId())
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found with id: " + dto.getPatientId()));

        Appointment appointment = toEntity(dto);
        if (appointment.getStatus() == null) {
            appointment.setStatus("SCHEDULED");
        }
        Appointment saved = appointmentRepository.save(appointment);

        // Maintain Doctor -> Appointments
        if (!doctor.getAppointmentIds().contains(saved.getId())) {
            doctor.getAppointmentIds().add(saved.getId());
            doctorRepository.save(doctor);
        }

        // Maintain Patient -> Appointments
        if (!patient.getAppointmentIds().contains(saved.getId())) {
            patient.getAppointmentIds().add(saved.getId());
            patientRepository.save(patient);
        }

        return toDTO(saved);
    }

    public List<AppointmentDTO> getAllAppointments() {
        return appointmentRepository.findAll()
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    public AppointmentDTO getAppointmentById(String id) {
        Appointment appointment = appointmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Appointment not found with id: " + id));
        return toDTO(appointment);
    }

    public List<AppointmentDTO> getAppointmentsByDoctor(String doctorId) {
        return appointmentRepository.findByDoctorId(doctorId)
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    public List<AppointmentDTO> getAppointmentsByPatient(String patientId) {
        return appointmentRepository.findByPatientId(patientId)
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    public AppointmentDTO updateAppointment(String id, AppointmentDTO dto) {
        Appointment existing = appointmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Appointment not found with id: " + id));

        String oldDoctorId = existing.getDoctorId();
        String oldPatientId = existing.getPatientId();

        // Handle doctor change
        if (dto.getDoctorId() != null && !dto.getDoctorId().equals(oldDoctorId)) {
            Doctor newDoctor = doctorRepository.findById(dto.getDoctorId())
                    .orElseThrow(() -> new ResourceNotFoundException("Doctor not found with id: " + dto.getDoctorId()));

            doctorRepository.findById(oldDoctorId).ifPresent(oldDoc -> {
                oldDoc.getAppointmentIds().remove(id);
                doctorRepository.save(oldDoc);
            });

            if (!newDoctor.getAppointmentIds().contains(id)) {
                newDoctor.getAppointmentIds().add(id);
                doctorRepository.save(newDoctor);
            }
            existing.setDoctorId(dto.getDoctorId());
        }

        // Handle patient change
        if (dto.getPatientId() != null && !dto.getPatientId().equals(oldPatientId)) {
            Patient newPatient = patientRepository.findById(dto.getPatientId())
                    .orElseThrow(() -> new ResourceNotFoundException("Patient not found with id: " + dto.getPatientId()));

            patientRepository.findById(oldPatientId).ifPresent(oldPat -> {
                oldPat.getAppointmentIds().remove(id);
                patientRepository.save(oldPat);
            });

            if (!newPatient.getAppointmentIds().contains(id)) {
                newPatient.getAppointmentIds().add(id);
                patientRepository.save(newPatient);
            }
            existing.setPatientId(dto.getPatientId());
        }

        existing.setAppointmentDateTime(dto.getAppointmentDateTime());
        existing.setReason(dto.getReason());
        if (dto.getStatus() != null) {
            existing.setStatus(dto.getStatus());
        }
        existing.setNotes(dto.getNotes());

        Appointment updated = appointmentRepository.save(existing);
        return toDTO(updated);
    }

    public void deleteAppointment(String id) {
        Appointment existing = appointmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Appointment not found with id: " + id));

        doctorRepository.findById(existing.getDoctorId()).ifPresent(doctor -> {
            doctor.getAppointmentIds().remove(id);
            doctorRepository.save(doctor);
        });

        patientRepository.findById(existing.getPatientId()).ifPresent(patient -> {
            patient.getAppointmentIds().remove(id);
            patientRepository.save(patient);
        });

        appointmentRepository.delete(existing);
    }

    private Appointment toEntity(AppointmentDTO dto) {
        return Appointment.builder()
                .id(dto.getId())
                .doctorId(dto.getDoctorId())
                .patientId(dto.getPatientId())
                .appointmentDateTime(dto.getAppointmentDateTime())
                .reason(dto.getReason())
                .status(dto.getStatus())
                .notes(dto.getNotes())
                .build();
    }

    private AppointmentDTO toDTO(Appointment appointment) {
        return AppointmentDTO.builder()
                .id(appointment.getId())
                .doctorId(appointment.getDoctorId())
                .patientId(appointment.getPatientId())
                .appointmentDateTime(appointment.getAppointmentDateTime())
                .reason(appointment.getReason())
                .status(appointment.getStatus())
                .notes(appointment.getNotes())
                .build();
    }
}
