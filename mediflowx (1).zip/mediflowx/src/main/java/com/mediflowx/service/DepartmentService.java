package com.mediflowx.service;

import com.mediflowx.dto.DepartmentDTO;
import com.mediflowx.exception.ResourceNotFoundException;
import com.mediflowx.model.Department;
import com.mediflowx.repository.DepartmentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class DepartmentService {

    private final DepartmentRepository departmentRepository;

    public DepartmentDTO createDepartment(DepartmentDTO dto) {
        Department department = toEntity(dto);
        Department saved = departmentRepository.save(department);
        return toDTO(saved);
    }

    public List<DepartmentDTO> getAllDepartments() {
        return departmentRepository.findAll()
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    public DepartmentDTO getDepartmentById(String id) {
        Department department = departmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Department not found with id: " + id));
        return toDTO(department);
    }

    public DepartmentDTO updateDepartment(String id, DepartmentDTO dto) {
        Department existing = departmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Department not found with id: " + id));

        existing.setName(dto.getName());
        existing.setDescription(dto.getDescription());
        existing.setLocation(dto.getLocation());
        if (dto.getDoctorIds() != null) {
            existing.setDoctorIds(dto.getDoctorIds());
        }

        Department updated = departmentRepository.save(existing);
        return toDTO(updated);
    }

    public void deleteDepartment(String id) {
        Department existing = departmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Department not found with id: " + id));
        departmentRepository.delete(existing);
    }

    public void addDoctorToDepartment(String departmentId, String doctorId) {
        Department department = departmentRepository.findById(departmentId)
                .orElseThrow(() -> new ResourceNotFoundException("Department not found with id: " + departmentId));
        if (!department.getDoctorIds().contains(doctorId)) {
            department.getDoctorIds().add(doctorId);
            departmentRepository.save(department);
        }
    }

    private Department toEntity(DepartmentDTO dto) {
        return Department.builder()
                .id(dto.getId())
                .name(dto.getName())
                .description(dto.getDescription())
                .location(dto.getLocation())
                .doctorIds(dto.getDoctorIds() != null ? dto.getDoctorIds() : new java.util.ArrayList<>())
                .build();
    }

    private DepartmentDTO toDTO(Department department) {
        return DepartmentDTO.builder()
                .id(department.getId())
                .name(department.getName())
                .description(department.getDescription())
                .location(department.getLocation())
                .doctorIds(department.getDoctorIds())
                .build();
    }
}
