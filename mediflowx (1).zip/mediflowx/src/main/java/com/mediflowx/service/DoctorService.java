package com.mediflowx.service;

import com.mediflowx.dto.DoctorDTO;
import com.mediflowx.exception.ResourceNotFoundException;
import com.mediflowx.model.Department;
import com.mediflowx.model.Doctor;
import com.mediflowx.model.Patient;
import com.mediflowx.repository.DepartmentRepository;
import com.mediflowx.repository.DoctorRepository;
import com.mediflowx.repository.PatientRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class DoctorService {

    private final DoctorRepository doctorRepository;
    private final DepartmentRepository departmentRepository;
    private final PatientRepository patientRepository;

    public DoctorDTO createDoctor(DoctorDTO dto) {
        // Validate department exists
        Department department = departmentRepository.findById(dto.getDepartmentId())
                .orElseThrow(() -> new ResourceNotFoundException("Department not found with id: " + dto.getDepartmentId()));

        Doctor doctor = toEntity(dto);
        Doctor saved = doctorRepository.save(doctor);

        // Maintain Department -> Doctors relationship
        if (!department.getDoctorIds().contains(saved.getId())) {
            department.getDoctorIds().add(saved.getId());
            departmentRepository.save(department);
        }

        return toDTO(saved);
    }

    public List<DoctorDTO> getAllDoctors() {
        return doctorRepository.findAll()
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    public DoctorDTO getDoctorById(String id) {
        Doctor doctor = doctorRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Doctor not found with id: " + id));
        return toDTO(doctor);
    }

    public List<DoctorDTO> getDoctorsByDepartment(String departmentId) {
        return doctorRepository.findByDepartmentId(departmentId)
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    public DoctorDTO updateDoctor(String id, DoctorDTO dto) {
        Doctor existing = doctorRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Doctor not found with id: " + id));

        String oldDepartmentId = existing.getDepartmentId();

        existing.setName(dto.getName());
        existing.setSpecialization(dto.getSpecialization());
        existing.setEmail(dto.getEmail());
        existing.setPhone(dto.getPhone());

        // Handle department change
        if (dto.getDepartmentId() != null && !dto.getDepartmentId().equals(oldDepartmentId)) {
            Department newDepartment = departmentRepository.findById(dto.getDepartmentId())
                    .orElseThrow(() -> new ResourceNotFoundException("Department not found with id: " + dto.getDepartmentId()));

            // remove from old department
            if (oldDepartmentId != null) {
                departmentRepository.findById(oldDepartmentId).ifPresent(oldDept -> {
                    oldDept.getDoctorIds().remove(id);
                    departmentRepository.save(oldDept);
                });
            }

            // add to new department
            if (!newDepartment.getDoctorIds().contains(id)) {
                newDepartment.getDoctorIds().add(id);
                departmentRepository.save(newDepartment);
            }

            existing.setDepartmentId(dto.getDepartmentId());
        }

        if (dto.getAppointmentIds() != null) {
            existing.setAppointmentIds(dto.getAppointmentIds());
        }
        if (dto.getPatientIds() != null) {
            existing.setPatientIds(dto.getPatientIds());
        }

        Doctor updated = doctorRepository.save(existing);
        return toDTO(updated);
    }

    public void deleteDoctor(String id) {
        Doctor existing = doctorRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Doctor not found with id: " + id));

        // Remove doctor reference from department
        if (existing.getDepartmentId() != null) {
            departmentRepository.findById(existing.getDepartmentId()).ifPresent(dept -> {
                dept.getDoctorIds().remove(id);
                departmentRepository.save(dept);
            });
        }

        // Remove doctor reference from patients (many-to-many)
        for (String patientId : existing.getPatientIds()) {
            patientRepository.findById(patientId).ifPresent(patient -> {
                patient.getDoctorIds().remove(id);
                patientRepository.save(patient);
            });
        }

        doctorRepository.delete(existing);
    }

    public void linkPatient(String doctorId, String patientId) {
        Doctor doctor = doctorRepository.findById(doctorId)
                .orElseThrow(() -> new ResourceNotFoundException("Doctor not found with id: " + doctorId));
        Patient patient = patientRepository.findById(patientId)
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found with id: " + patientId));

        if (!doctor.getPatientIds().contains(patientId)) {
            doctor.getPatientIds().add(patientId);
            doctorRepository.save(doctor);
        }
        if (!patient.getDoctorIds().contains(doctorId)) {
            patient.getDoctorIds().add(doctorId);
            patientRepository.save(patient);
        }
    }

    public void unlinkPatient(String doctorId, String patientId) {
        Doctor doctor = doctorRepository.findById(doctorId)
                .orElseThrow(() -> new ResourceNotFoundException("Doctor not found with id: " + doctorId));
        Patient patient = patientRepository.findById(patientId)
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found with id: " + patientId));

        doctor.getPatientIds().remove(patientId);
        patient.getDoctorIds().remove(doctorId);

        doctorRepository.save(doctor);
        patientRepository.save(patient);
    }

    public void addAppointment(String doctorId, String appointmentId) {
        Doctor doctor = doctorRepository.findById(doctorId)
                .orElseThrow(() -> new ResourceNotFoundException("Doctor not found with id: " + doctorId));
        if (!doctor.getAppointmentIds().contains(appointmentId)) {
            doctor.getAppointmentIds().add(appointmentId);
            doctorRepository.save(doctor);
        }
    }

    public void removeAppointment(String doctorId, String appointmentId) {
        doctorRepository.findById(doctorId).ifPresent(doctor -> {
            doctor.getAppointmentIds().remove(appointmentId);
            doctorRepository.save(doctor);
        });
    }

    private Doctor toEntity(DoctorDTO dto) {
        return Doctor.builder()
                .id(dto.getId())
                .name(dto.getName())
                .specialization(dto.getSpecialization())
                .email(dto.getEmail())
                .phone(dto.getPhone())
                .departmentId(dto.getDepartmentId())
                .appointmentIds(dto.getAppointmentIds() != null ? dto.getAppointmentIds() : new ArrayList<>())
                .patientIds(dto.getPatientIds() != null ? dto.getPatientIds() : new ArrayList<>())
                .build();
    }

    private DoctorDTO toDTO(Doctor doctor) {
        return DoctorDTO.builder()
                .id(doctor.getId())
                .name(doctor.getName())
                .specialization(doctor.getSpecialization())
                .email(doctor.getEmail())
                .phone(doctor.getPhone())
                .departmentId(doctor.getDepartmentId())
                .appointmentIds(doctor.getAppointmentIds())
                .patientIds(doctor.getPatientIds())
                .build();
    }
}
