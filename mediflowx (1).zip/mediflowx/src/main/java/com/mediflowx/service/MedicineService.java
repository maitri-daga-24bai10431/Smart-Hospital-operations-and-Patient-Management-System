package com.mediflowx.service;

import com.mediflowx.dto.MedicineDTO;
import com.mediflowx.exception.ResourceNotFoundException;
import com.mediflowx.model.Medicine;
import com.mediflowx.repository.MedicineRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class MedicineService {

    private final MedicineRepository medicineRepository;

    public MedicineDTO createMedicine(MedicineDTO dto) {
        Medicine medicine = toEntity(dto);
        Medicine saved = medicineRepository.save(medicine);
        return toDTO(saved);
    }

    public List<MedicineDTO> getAllMedicines() {
        return medicineRepository.findAll()
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    public MedicineDTO getMedicineById(String id) {
        Medicine medicine = medicineRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Medicine not found with id: " + id));
        return toDTO(medicine);
    }

    public MedicineDTO updateMedicine(String id, MedicineDTO dto) {
        Medicine existing = medicineRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Medicine not found with id: " + id));

        existing.setName(dto.getName());
        existing.setManufacturer(dto.getManufacturer());
        existing.setDescription(dto.getDescription());
        existing.setPrice(dto.getPrice());
        existing.setStockQuantity(dto.getStockQuantity());
        existing.setDosageForm(dto.getDosageForm());
        existing.setExpiryDate(dto.getExpiryDate());

        Medicine updated = medicineRepository.save(existing);
        return toDTO(updated);
    }

    public void deleteMedicine(String id) {
        Medicine existing = medicineRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Medicine not found with id: " + id));
        medicineRepository.delete(existing);
    }

    private Medicine toEntity(MedicineDTO dto) {
        return Medicine.builder()
                .id(dto.getId())
                .name(dto.getName())
                .manufacturer(dto.getManufacturer())
                .description(dto.getDescription())
                .price(dto.getPrice())
                .stockQuantity(dto.getStockQuantity())
                .dosageForm(dto.getDosageForm())
                .expiryDate(dto.getExpiryDate())
                .build();
    }

    private MedicineDTO toDTO(Medicine medicine) {
        return MedicineDTO.builder()
                .id(medicine.getId())
                .name(medicine.getName())
                .manufacturer(medicine.getManufacturer())
                .description(medicine.getDescription())
                .price(medicine.getPrice())
                .stockQuantity(medicine.getStockQuantity())
                .dosageForm(medicine.getDosageForm())
                .expiryDate(medicine.getExpiryDate())
                .build();
    }
}
