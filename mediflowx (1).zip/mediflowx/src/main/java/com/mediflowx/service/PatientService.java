package com.mediflowx.service;

import com.mediflowx.dto.PatientDTO;
import com.mediflowx.exception.ResourceNotFoundException;
import com.mediflowx.model.Doctor;
import com.mediflowx.model.Patient;
import com.mediflowx.repository.DoctorRepository;
import com.mediflowx.repository.PatientRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class PatientService {

    private final PatientRepository patientRepository;
    private final DoctorRepository doctorRepository;

    public PatientDTO createPatient(PatientDTO dto) {
        Patient patient = toEntity(dto);
        Patient saved = patientRepository.save(patient);
        return toDTO(saved);
    }

    public List<PatientDTO> getAllPatients() {
        return patientRepository.findAll()
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    public PatientDTO getPatientById(String id) {
        Patient patient = patientRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found with id: " + id));
        return toDTO(patient);
    }

    public PatientDTO updatePatient(String id, PatientDTO dto) {
        Patient existing = patientRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found with id: " + id));

        existing.setName(dto.getName());
        existing.setAge(dto.getAge());
        existing.setGender(dto.getGender());
        existing.setEmail(dto.getEmail());
        existing.setPhone(dto.getPhone());
        existing.setAddress(dto.getAddress());

        if (dto.getDoctorIds() != null) {
            existing.setDoctorIds(dto.getDoctorIds());
        }
        if (dto.getAppointmentIds() != null) {
            existing.setAppointmentIds(dto.getAppointmentIds());
        }

        Patient updated = patientRepository.save(existing);
        return toDTO(updated);
    }

    public void deletePatient(String id) {
        Patient existing = patientRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found with id: " + id));

        // Remove patient reference from linked doctors (many-to-many)
        for (String doctorId : existing.getDoctorIds()) {
            doctorRepository.findById(doctorId).ifPresent(doctor -> {
                doctor.getPatientIds().remove(id);
                doctorRepository.save(doctor);
            });
        }

        patientRepository.delete(existing);
    }

    public void addAppointment(String patientId, String appointmentId) {
        Patient patient = patientRepository.findById(patientId)
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found with id: " + patientId));
        if (!patient.getAppointmentIds().contains(appointmentId)) {
            patient.getAppointmentIds().add(appointmentId);
            patientRepository.save(patient);
        }
    }

    public void removeAppointment(String patientId, String appointmentId) {
        patientRepository.findById(patientId).ifPresent(patient -> {
            patient.getAppointmentIds().remove(appointmentId);
            patientRepository.save(patient);
        });
    }

    private Patient toEntity(PatientDTO dto) {
        return Patient.builder()
                .id(dto.getId())
                .name(dto.getName())
                .age(dto.getAge())
                .gender(dto.getGender())
                .email(dto.getEmail())
                .phone(dto.getPhone())
                .address(dto.getAddress())
                .doctorIds(dto.getDoctorIds() != null ? dto.getDoctorIds() : new ArrayList<>())
                .appointmentIds(dto.getAppointmentIds() != null ? dto.getAppointmentIds() : new ArrayList<>())
                .build();
    }

    private PatientDTO toDTO(Patient patient) {
        return PatientDTO.builder()
                .id(patient.getId())
                .name(patient.getName())
                .age(patient.getAge())
                .gender(patient.getGender())
                .email(patient.getEmail())
                .phone(patient.getPhone())
                .address(patient.getAddress())
                .doctorIds(patient.getDoctorIds())
                .appointmentIds(patient.getAppointmentIds())
                .build();
    }
}
